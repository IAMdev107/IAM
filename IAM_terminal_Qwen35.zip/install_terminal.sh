#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m pip install --upgrade pip requests SpeechRecognition piper-tts
if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update
  sudo apt-get install -y portaudio19-dev python3-dev alsa-utils ffmpeg curl
fi
python3 -m pip install PyAudio
mkdir -p voices
base="https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/medium"
curl -L --fail "$base/pt_BR-faber-medium.onnx" -o voices/pt_BR-faber-medium.onnx
curl -L --fail "$base/pt_BR-faber-medium.onnx.json" -o voices/pt_BR-faber-medium.onnx.json
echo
echo "IAM instalada."
echo "Teste: ollama run qwen3.5:latest"
echo "Inicie: ./IAM_terminal.py"
