# IAM Terminal

Terminal-only: você digita no terminal, a resposta aparece em streaming no terminal e a IAM fala a resposta com Piper.

## Instalar
```bash
chmod +x install_terminal.sh
./install_terminal.sh
```

## Rodar
```bash
./IAM_terminal.py
```

Modelo padrão: `qwen3.5:latest`

## Comandos
`/voz on` ` /voz off` ` /mic` ` /limpar` ` /modelo` ` /sair`

Para testar sem voz:
```bash
IAM_VOICE=0 ./IAM_terminal.py
```

Se o Ollama não estiver rodando:
```bash
ollama serve
```
