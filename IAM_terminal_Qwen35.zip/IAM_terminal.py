#!/usr/bin/env python3
import json, os, shutil, subprocess, sys, tempfile
from pathlib import Path
import requests

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434/api/chat")
MODEL = os.getenv("OLLAMA_MODEL", "qwen3.5:latest")
VOICE = os.getenv("IAM_TTS_VOICE", "pt_BR-faber-medium")
MEMORY_FILE = Path("iam_memory.json")
history = []

SYSTEM = """Você é a IAM (Intelligent Artificial Machine), assistente pessoal
especializada em programação, tecnologia, automação e cibersegurança defensiva.

MODO PROGRAMADOR:
- Identifique linguagem e causa do erro.
- Explique o problema.
- Mostre código corrigido.
- Mostre uma versão melhorada quando fizer sentido.
- Informe dependências e execução quando necessário.
- Não diga que executou/testou algo se não executou.
- Preserve a intenção do usuário.
- Trabalhe com Python, C, C++, C#, Java, JavaScript, TypeScript, Rust,
Go, HTML, CSS, SQL, Bash e PowerShell.

CIBERSEGURANÇA: priorize defesa, auditoria, hardening, logs e ambientes autorizados.
PERSONALIDADE: inteligente, confiante, espontânea; humor/sarcasmo apenas quando apropriado.
Responda em português brasileiro por padrão.
Prioridade: precisão > segurança > utilidade > clareza > personalidade."""

def load():
    global history
    history = []
    if MEMORY_FILE.exists():
        try:
            x=json.loads(MEMORY_FILE.read_text(encoding="utf-8"))
            history=x.get("history", [])[-16:]
        except Exception: pass

def save():
    MEMORY_FILE.write_text(json.dumps({"history":history[-16:]},ensure_ascii=False,indent=2),encoding="utf-8")

def speak(text):
    if os.getenv("IAM_VOICE","1")=="0": return
    piper=shutil.which("piper")
    model=Path("voices")/(VOICE+".onnx")
    if not piper or not model.exists():
        print("[VOZ] Piper/modelo não encontrado. Rode ./install_terminal.sh")
        return
    try:
        with tempfile.TemporaryDirectory() as d:
            wav=Path(d)/"iam.wav"
            subprocess.run([piper,"--model",str(model),"--output_file",str(wav)],
                           input=text,text=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,check=True)
            player=shutil.which("aplay") or shutil.which("paplay") or shutil.which("ffplay")
            if not player: return
            if Path(player).name=="aplay": subprocess.run([player,"-q",str(wav)],check=False)
            elif Path(player).name=="paplay": subprocess.run([player,str(wav)],check=False)
            else: subprocess.run([player,"-nodisp","-autoexit","-loglevel","quiet",str(wav)],check=False)
    except Exception as e: print("[VOZ] erro:",e)

def ask(text):
    history.append({"role":"user","content":text})
    msgs=[{"role":"system","content":SYSTEM}]+history[-16:]
    payload={"model":MODEL,"messages":msgs,"stream":True,"keep_alive":"10m",
             "options":{"temperature":0.7,"top_p":0.9,"num_ctx":4096,"num_predict":2048}}
    answer=[]
    try:
        with requests.post(OLLAMA_URL,json=payload,stream=True,timeout=(10,600)) as r:
            r.raise_for_status()
            print("IAM: ",end="",flush=True)
            for line in r.iter_lines(decode_unicode=True):
                if not line: continue
                if isinstance(line,bytes):
                    line=line.decode("utf-8",errors="replace")
                try: obj=json.loads(line)
                except json.JSONDecodeError: continue
                part=obj.get("message",{}).get("content","")
                if part:
                    answer.append(part); print(part,end="",flush=True)
            print()
        out="".join(answer).strip()
        history.append({"role":"assistant","content":out}); save()
        return out
    except requests.exceptions.ConnectionError:
        print("\n[IAM] Ollama não está acessível. Rode: ollama serve"); return ""
    except requests.exceptions.Timeout:
        print("\n[IAM] O Qwen demorou demais para responder."); return ""
    except Exception as e:
        print("\n[IAM] Erro:",e); return ""

def microphone():
    try:
        import speech_recognition as sr
    except ImportError:
        print("[MIC] Instale as dependências com ./install_terminal.sh"); return
    rec=sr.Recognizer()
    print("[MIC] Ctrl+C para sair.")
    while True:
        try:
            with sr.Microphone() as source:
                print("\n🎤 IAM ouvindo...")
                rec.adjust_for_ambient_noise(source,duration=.3)
                audio=rec.listen(source,timeout=10,phrase_time_limit=30)
            print("[MIC] Convertendo...")
            text=rec.recognize_google(audio,language="pt-BR")
            print("Você:",text)
            out=ask(text)
            if out: speak(out)
        except KeyboardInterrupt: print("\n[MIC] encerrado."); return
        except sr.WaitTimeoutError: print("[MIC] tempo esgotado.")
        except sr.UnknownValueError: print("[MIC] não entendi.")
        except Exception as e: print("[MIC] erro:",e)

def main():
    load()
    print("="*58)
    print(" IAM — TERMINAL | Qwen3.5 + Piper")
    print("="*58)
    print("Comandos: /ajuda /voz on /voz off /mic /limpar /modelo /sair")
    while True:
        try: text=input("\nVocê: ").strip()
        except (KeyboardInterrupt,EOFError): print("\n[IAM] encerrando."); break
        if not text: continue
        cmd=text.lower()
        if cmd in ("/sair","sair","exit","quit"): break
        if cmd=="/ajuda":
            print("/voz on | /voz off | /mic | /limpar | /modelo | /sair"); continue
        if cmd=="/voz on": os.environ["IAM_VOICE"]="1"; print("[IAM] voz ligada."); continue
        if cmd=="/voz off": os.environ["IAM_VOICE"]="0"; print("[IAM] voz desligada."); continue
        if cmd=="/modelo": print("[IAM]",MODEL); continue
        if cmd=="/limpar": history.clear(); save(); print("[IAM] memória apagada."); continue
        out=ask(text)
        if out: speak(out)

if __name__=="__main__": main()
