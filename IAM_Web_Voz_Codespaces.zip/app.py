from pathlib import Path
import json, os
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import requests

BASE=Path(__file__).parent
MEM=BASE/"iam_memory.json"
OLLAMA_URL=os.getenv("OLLAMA_URL","http://127.0.0.1:11434/api/chat")
MODEL=os.getenv("OLLAMA_MODEL","qwen3.5:latest")

app=FastAPI(title="IAM")
app.mount("/static",StaticFiles(directory=BASE/"static"),name="static")
templates=Jinja2Templates(directory=str(BASE/"templates"))

modes={
"assistente":"Converse normalmente, seja útil, natural e claro.",
"programador":"Modo Programador: analise código, encontre erros, explique causas, corrija e melhore. Não invente execuções.",
"ciberseguranca":"Modo Cibersegurança: foco defensivo, logs, hardening, auditoria e testes autorizados.",
"humor":"Modo Humor: seja descontraída, usando sarcasmo e piadas de tecnologia quando apropriado.",
"profissional":"Modo Profissional: seja objetiva, técnica e sem piadas desnecessárias."
}
system="""Você é a IAM (Intelligent Artificial Machine), assistente em português brasileiro
especializada em programação, tecnologia, automação e cibersegurança defensiva.
Priorize precisão, segurança, utilidade e clareza. Você não deve fingir ter realizado
ações que não realizou."""
history=[]

def load():
    global history
    try: history=json.loads(MEM.read_text(encoding="utf8")).get("history",[])[-20:]
    except: history=[]
def save():
    MEM.write_text(json.dumps({"history":history[-20:]},ensure_ascii=False,indent=2),encoding="utf8")

load()

@app.get("/",response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request=request,name="index.html")

@app.get("/api/status")
async def status():
    try:
        r=requests.get(OLLAMA_URL.replace("/api/chat","/api/tags"),timeout=3)
        online=r.ok
    except: online=False
    return {"ollama":online,"model":MODEL,"memory":len(history)}

@app.post("/api/chat")
async def chat(payload: dict):
    global history
    text=str(payload.get("message","")).strip()
    mode=str(payload.get("mode","assistente"))
    if not text: return {"response":""}
    if mode not in modes: mode="assistente"
    history.append({"role":"user","content":text})
    body={"model":MODEL,"messages":[
        {"role":"system","content":system+"\n\n"+modes[mode]},
        *history[-20:]
    ],"stream":False,"keep_alive":"10m",
    "options":{"temperature":0.7,"top_p":0.9,"num_ctx":4096,"num_predict":2048}}
    try:
        r=requests.post(OLLAMA_URL,json=body,timeout=600)
        r.raise_for_status()
        answer=r.json().get("message",{}).get("content","")
    except requests.exceptions.ConnectionError:
        answer="Não consegui conectar ao Ollama. No Codespace, verifique se `ollama serve` está executando."
    except Exception as e:
        answer=f"Erro ao consultar o Ollama: {e}"
    history.append({"role":"assistant","content":answer})
    save()
    return {"response":answer}

@app.post("/api/clear")
async def clear():
    global history
    history=[]
    save()
    return {"ok":True}
