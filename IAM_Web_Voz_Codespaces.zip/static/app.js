const chat=document.querySelector("#chat"), form=document.querySelector("#form");
const input=document.querySelector("#input"), mode=document.querySelector("#mode");
const mic=document.querySelector("#mic"), stop=document.querySelector("#stop");
const voice=document.querySelector("#voice"), status=document.querySelector("#status");
let recognition=null, speaking=false;

function add(text,who){
  const d=document.createElement("div"); d.className="msg "+who; d.textContent=text;
  chat.appendChild(d); chat.scrollTop=chat.scrollHeight; return d;
}
function speak(text){
  if(!voice.checked || !("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);
  u.lang="pt-BR"; u.rate=1.0; u.pitch=1.0; u.volume=1;
  const voices=speechSynthesis.getVoices();
  const pt=voices.find(v=>v.lang && v.lang.toLowerCase().startsWith("pt-br")) ||
           voices.find(v=>v.lang && v.lang.toLowerCase().startsWith("pt"));
  if(pt) u.voice=pt;
  speechSynthesis.speak(u);
}
async function send(text){
  text=text.trim(); if(!text)return;
  add(text,"user"); input.value="";
  const d=add("IAM: pensando...","iam");
  try{
    const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({message:text,mode:mode.value})});
    const data=await r.json(); d.textContent=data.response||"Não houve resposta.";
    speak(data.response||"");
  }catch(e){d.textContent="Erro de comunicação com a IAM: "+e}
}
form.addEventListener("submit",e=>{e.preventDefault();send(input.value)});
document.querySelector("#clear").onclick=async()=>{await fetch("/api/clear",{method:"POST"});chat.innerHTML=""};

function setupVoice(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){mic.disabled=true;mic.title="Speech Recognition não disponível neste navegador";return}
  recognition=new SR(); recognition.lang="pt-BR"; recognition.interimResults=false; recognition.continuous=false;
  recognition.onstart=()=>{mic.classList.add("listening");mic.textContent="🎤 Ouvindo...";stop.disabled=false};
  recognition.onend=()=>{mic.classList.remove("listening");mic.textContent="🎤 Falar";stop.disabled=true};
  recognition.onerror=e=>{console.warn(e);recognition.stop()};
  recognition.onresult=e=>{const t=e.results[0][0].transcript;send(t)};
  mic.onclick=()=>{try{recognition.start()}catch{}};
  stop.onclick=()=>recognition.stop();
}
setupVoice();
async function check(){
  try{const d=await (await fetch("/api/status")).json();
    status.textContent=d.ollama?"● Ollama online — "+d.model:"● Ollama offline";
    status.style.color=d.ollama?"#70e1a5":"#ff9b9b";
  }catch{status.textContent="● servidor offline"}
}
check(); setInterval(check,10000);
