#!/bin/bash
set -e
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
echo ""
echo "IAM instalada."
echo "Execute:"
echo "  ollama serve"
echo "em outro terminal e depois:"
echo "  uvicorn app:app --host 0.0.0.0 --port 8000"
echo ""
echo "Abra a porta 8000 no Codespaces."
