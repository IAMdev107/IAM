# IAM Web + Voz — GitHub Codespaces

A IAM roda no Codespace, mas **microfone e alto-falante ficam no navegador do usuário**.
Assim ela não depende de ALSA/JACK/aplay/placa de som do servidor.

## Instalar

```bash
chmod +x install.sh
./install.sh
```

## Ollama

```bash
ollama list
ollama pull qwen3.5:latest
```

Em outro terminal:

```bash
ollama serve
```

## Rodar

```bash
uvicorn app:app --host 0.0.0.0 --port 8000
```

No GitHub Codespaces, abra a porta `8000` usando a aba **Ports** e clique no link
**Open in Browser**.

## Voz

- 🎤 usa Speech Recognition do navegador;
- 🔊 usa Speech Synthesis do navegador;
- não usa ALSA;
- não usa `aplay`;
- não precisa de placa de som no Codespace.

A voz usada é a voz brasileira disponível no navegador/sistema. O perfil pode variar
conforme o navegador e o dispositivo.
