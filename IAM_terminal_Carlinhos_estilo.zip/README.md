# IAM Terminal — Qwen3.5

Versão da IAM feita para funcionar diretamente no terminal.

## Recursos

- Qwen3.5 via Ollama
- Resposta em streaming no terminal
- Memória local
- Text-to-Speech
- Speech-to-Text
- Microfone
- Voz normal
- Perfil de voz meme
- Modo programador
- Assistência de programação
- Cibersegurança defensiva

## Instalação

```bash
chmod +x install_terminal.sh
./install_terminal.sh
```

## Rodar

```bash
./IAM_terminal.py
```

## Ollama

Confira:

```bash
ollama list
```

O modelo esperado é:

```text
qwen3.5:latest
```

Se não estiver instalado:

```bash
ollama pull qwen3.5:latest
```

Se o servidor não estiver rodando:

```bash
ollama serve
```

## Voz

```text
/voz on
/voz off
/voz normal
/voz meme
```

O perfil `meme` usa uma voz neural brasileira e altera o ritmo para um
estilo exagerado de meme. Não é uma clonagem da voz de uma pessoa real.

## Microfone

```text
/mic
```

A IAM escuta, converte fala para texto, envia ao Qwen3.5, mostra a resposta
no terminal e fala a resposta.

## Memória

A conversa é salva em:

```text
iam_memory.json
```

Para apagar:

```text
/limpar
```
