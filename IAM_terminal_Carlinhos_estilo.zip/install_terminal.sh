#!/usr/bin/env bash
set -e

cd "$(dirname "$0")"

echo "========================================"
echo " INSTALADOR IAM"
echo " Qwen3.5 + Piper + Microfone"
echo "========================================"

python3 -m pip install --upgrade pip
python3 -m pip install requests SpeechRecognition piper-tts

if command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update
    sudo apt-get install -y \
        portaudio19-dev \
        python3-dev \
        alsa-utils \
        ffmpeg \
        curl
fi

python3 -m pip install PyAudio

mkdir -p voices

VOICE_BASE="https://huggingface.co/rhasspy/piper-voices/resolve/main/pt/pt_BR/faber/medium"

echo "[1/2] Baixando voz brasileira..."

curl -L --fail \
    "$VOICE_BASE/pt_BR-faber-medium.onnx" \
    -o voices/pt_BR-faber-medium.onnx

curl -L --fail \
    "$VOICE_BASE/pt_BR-faber-medium.onnx.json" \
    -o voices/pt_BR-faber-medium.onnx.json

echo
echo "========================================"
echo " IAM instalada!"
echo "========================================"
echo
echo "Modelo esperado:"
echo "  qwen3.5:latest"
echo
echo "Se necessário:"
echo "  ollama pull qwen3.5:latest"
echo
echo "Execute:"
echo "  ./IAM_terminal.py"
echo
echo "Depois use:"
echo "  /voz meme"
echo
