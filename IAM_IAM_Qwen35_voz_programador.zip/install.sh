#!/usr/bin/env bash
set -Eeuo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_DIR"

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

log()  { echo -e "${GREEN}[IAM]${NC} $1"; }
warn() { echo -e "${YELLOW}[IAM]${NC} $1"; }
die()  { echo -e "${RED}[IAM]${NC} $1"; exit 1; }

log "Instalador da IAM"
log "Diretório: $PROJECT_DIR"

command -v python3 >/dev/null 2>&1 || die "Python 3 não encontrado."
command -v curl >/dev/null 2>&1 || die "curl não encontrado."

PYTHON_BIN="$(command -v python3)"

if ! "$PYTHON_BIN" -m venv --help >/dev/null 2>&1; then
    warn "python3-venv não parece instalado."
    if command -v sudo >/dev/null 2>&1; then
        sudo apt-get update
        sudo apt-get install -y python3-venv python3-pip
    else
        die "Instale python3-venv e python3-pip e execute novamente."
    fi
fi

# Dependências opcionais do Linux. A IAM não usa PyAudio.
if command -v apt-get >/dev/null 2>&1 && command -v sudo >/dev/null 2>&1; then
    log "Verificando ferramentas básicas do Linux..."
    sudo apt-get update -y
    sudo apt-get install -y curl ca-certificates python3-venv python3-pip
fi

# Ollama
if command -v ollama >/dev/null 2>&1; then
    log "Ollama já está instalado."
else
    log "Instalando Ollama..."
    curl -fsSL https://ollama.com/install.sh | sh
fi

command -v ollama >/dev/null 2>&1 || die "Ollama não ficou disponível no PATH."

# Python virtual environment
if [ ! -d ".venv" ]; then
    log "Criando ambiente Python..."
    "$PYTHON_BIN" -m venv .venv
fi

source .venv/bin/activate

log "Atualizando pip..."
python -m pip install --upgrade pip wheel setuptools

log "Instalando dependências Python..."
python -m pip install -r requirements.txt

# Voz neural local (Piper) — evita a voz robótica do navegador.
log "Baixando voz neural brasileira da IAM..."
python -m piper.download_voices pt_BR-faber-medium || warn "Não foi possível baixar a voz agora. A IAM usará fallback do navegador."

# Start Ollama if needed.
if ! curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    log "Iniciando servidor Ollama..."
    nohup ollama serve > "$PROJECT_DIR/ollama.log" 2>&1 &
    OLLAMA_PID=$!
    echo "$OLLAMA_PID" > "$PROJECT_DIR/ollama.pid"

    for _ in $(seq 1 30); do
        if curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
            break
        fi
        sleep 1
    done
fi

curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1 || \
    die "Ollama não respondeu em http://127.0.0.1:11434. Veja ollama.log."

MODEL="${OLLAMA_MODEL:-qwen3.5:latest}"

log "Verificando modelo base: $MODEL"
if ! ollama list | awk 'NR>1 {print $1}' | grep -Fxq "$MODEL"; then
    log "Baixando $MODEL. Isso pode ocupar vários GB."
    ollama pull "$MODEL"
else
    log "$MODEL já está instalado."
fi

# Create/update custom IAM model.
log "Criando modelo personalizado IAM..."
ollama create IAM -f Modelfile

# Initial memory file if missing.
if [ ! -f memory.json ]; then
    printf '%s\n' '{"user":{},"facts":[],"preferences":[],"projects":[]}' > memory.json
fi

chmod +x start.sh stop.sh 2>/dev/null || true

log "Instalação concluída."
echo
echo "=============================================="
echo " IAM instalada com sucesso"
echo "=============================================="
echo
echo "Para iniciar:"
echo "  ./start.sh"
echo
echo "Depois abra:"
echo "  http://localhost:8000"
echo
echo "GitHub Codespaces: encaminhe a porta 8000."
echo
