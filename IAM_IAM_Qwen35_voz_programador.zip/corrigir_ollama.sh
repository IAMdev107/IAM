#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

python3 - <<'PY'
from pathlib import Path

p = Path("app.py")
s = p.read_text(encoding="utf-8")

old = '''                for line in response.iter_lines(decode_unicode=True):
                    if line:
                        yield line + "\\n"
'''
new = '''                for line in response.iter_lines(decode_unicode=True):
                    if line:
                        if isinstance(line, bytes):
                            line = line.decode("utf-8", errors="replace")
                        yield line + "\\n"
'''

if old not in s:
    raise SystemExit("Trecho antigo não encontrado.")
p.write_text(s.replace(old, new), encoding="utf-8")
print("Correção aplicada: bytes -> str no streaming do Ollama.")
PY

pkill -f "uvicorn app:app" 2>/dev/null || true
echo "Correção concluída. Execute ./start.sh"
