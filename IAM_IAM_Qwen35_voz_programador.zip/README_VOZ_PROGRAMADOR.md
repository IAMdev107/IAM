# IAM — Voz neural + Modo Programador aprimorado

Esta versão troca a voz `speechSynthesis` do navegador por **Piper TTS local**.
O Piper suporta português brasileiro e possui vozes `pt_BR`, incluindo `pt_BR-faber-medium`.
A voz Faber é brasileira, 22.05 kHz, tamanho médio e licença CC0 conforme o model card.

Fontes:
- Piper TTS: https://github.com/OHF-Voice/piper1-gpl
- Voz Faber: https://huggingface.co/rhasspy/piper-voices/tree/main/pt/pt_BR/faber/medium

## Instalação

```bash
cd /home/iam/IAM
./install.sh
```

Se a IAM já estiver instalada:

```bash
./voz.sh
```

## Voz

Por padrão:

```text
pt_BR-faber-medium
```

Para trocar para outra voz brasileira disponível, por exemplo `pt_BR-jeff-medium`:

```bash
IAM_TTS_VOICE=pt_BR-jeff-medium ./voz.sh
```

## Importante

O áudio é sintetizado no servidor e enviado ao navegador como WAV. Isso evita depender do
ALSA/JACK para a fala da IAM e também permite interromper a fala pelo botão `Parar voz`.

## Modo Programador

O prompt foi reforçado para:
- diagnóstico e causa de bugs;
- correção preservando intenção;
- código completo e executável;
- dependências e comandos de execução;
- testes quando fizer sentido;
- não inventar resultados de execução;
- arquitetura de projetos;
- tratamento de erros e segurança;
- respostas mais diretas quando o usuário pedir apenas código.
