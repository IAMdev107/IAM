#!/usr/bin/env bash
set -e
cd "$(dirname "${BASH_SOURCE[0]}")"

pkill -f "uvicorn app:app" 2>/dev/null || true

if [ -f ollama.pid ]; then
    PID="$(cat ollama.pid)"
    kill "$PID" 2>/dev/null || true
    rm -f ollama.pid
fi

echo "[IAM] Serviços da aplicação encerrados."
