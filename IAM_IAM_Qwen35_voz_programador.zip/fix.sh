#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

echo "[IAM] Corrigindo dependências e TemplateResponse..."
if [ ! -d .venv ]; then
  echo "[IAM] .venv não existe. Execute ./install.sh primeiro."
  exit 1
fi

source .venv/bin/activate
python -m pip install --upgrade "fastapi>=0.116,<1" "uvicorn[standard]>=0.35,<1" "jinja2>=3.1,<4"

echo "[IAM] Correção aplicada."
echo "[IAM] Agora execute: ./start.sh"
