"""Local Piper TTS helper for IAM."""
from __future__ import annotations

import os
import re
import shutil
import subprocess
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
VOICE = os.getenv("IAM_TTS_VOICE", "pt_BR-faber-medium")
PIPER_BIN = os.getenv("IAM_PIPER_BIN", str(BASE_DIR / ".venv" / "bin" / "piper"))


def speech_clean(text: str) -> str:
    """Convert an LLM response into natural speech, removing code/markdown noise."""
    text = re.sub(r"```[\s\S]*?```", " Trecho de código omitido. ", text)
    text = re.sub(r"`([^`]*)`", r"\1", text)
    text = re.sub(r"https?://\S+", " link ", text)
    text = re.sub(r"\[[^\]]*\]\([^)]*\)", "", text)
    text = re.sub(r"^\s{0,3}#{1,6}\s*", "", text, flags=re.MULTILINE)
    text = re.sub(r"^\s*[-*+]\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"^\s*\d+[.)]\s+", "", text, flags=re.MULTILINE)
    text = re.sub(r"[*_~]", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text[:5000]


def synthesize(text: str, output: Path, length_scale: float = 1.02) -> None:
    cleaned = speech_clean(text)
    if not cleaned:
        raise ValueError("Texto vazio para síntese.")

    binary = PIPER_BIN if Path(PIPER_BIN).exists() else shutil.which("piper")
    if not binary:
        raise RuntimeError("Piper TTS não encontrado. Execute ./install.sh")

    cmd = [
        binary,
        "--model", VOICE,
        "--output_file", str(output),
        "--length_scale", str(length_scale),
        "--noise_scale", "0.667",
        "--noise_w", "0.8",
    ]
    subprocess.run(
        cmd,
        input=cleaned,
        text=True,
        capture_output=True,
        check=True,
        timeout=120,
    )
