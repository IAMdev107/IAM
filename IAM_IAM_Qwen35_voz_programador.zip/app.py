import json
import os
import tempfile
from pathlib import Path

import requests
from fastapi import FastAPI, File, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from starlette.requests import Request

from voice_tts import synthesize, speech_clean

BASE_DIR = Path(__file__).resolve().parent
MEMORY_FILE = BASE_DIR / "memory.json"

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434/api/chat")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen3.5:latest")
OLLAMA_TIMEOUT = int(os.getenv("OLLAMA_TIMEOUT", "900"))
OLLAMA_NUM_CTX = int(os.getenv("OLLAMA_NUM_CTX", "4096"))

app = FastAPI(title="IAM - Intelligent Artificial Machine")
app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))

MODE_PROMPTS = {
    "assistente": "Converse naturalmente e ajude em perguntas, estudos, tecnologia e tarefas gerais.",
    "programador": """Você está no MODO PROGRAMADOR e deve agir como uma engenheira de software sênior.

REGRAS DO MODO PROGRAMADOR:
- Identifique automaticamente a linguagem e o ambiente quando possível.
- Ao receber código com erro: mostre o diagnóstico, causa, correção e versão final.
- Preserve a intenção original do código; não faça mudanças desnecessárias.
- Prefira soluções simples, robustas, legíveis, testáveis e compatíveis com a versão indicada.
- Ao criar código, entregue código completo e executável quando isso for viável.
- Inclua imports/dependências necessários e comandos de instalação quando relevantes.
- Para bugs, explique exatamente onde está o problema e por que ocorre.
- Para projetos maiores, proponha estrutura de arquivos antes de espalhar código sem organização.
- Ao trabalhar com APIs, bancos de dados ou arquivos, trate erros, validação e recursos com segurança.
- Não invente resultados de testes. Se não executou o código, diga claramente que ele não foi executado.
- Quando fizer sentido, inclua testes unitários ou um pequeno teste de verificação.
- Use blocos de código com a linguagem correta.
- Não misture código com explicações dentro do bloco de código.
- Se o pedido estiver incompleto, faça a melhor suposição possível e declare a suposição em uma frase curta.

FORMATO PREFERIDO:
1. Diagnóstico
2. Causa
3. Correção
4. Código
5. Como executar/testar
6. Melhorias opcionais

Se o usuário pedir apenas código, seja direto e entregue o código sem uma aula desnecessária.
Priorize precisão e funcionamento sobre respostas longas.""",
    "ciberseguranca": """Foque em cibersegurança defensiva, hardening, logs, auditoria,
monitoramento, análise de vulnerabilidades e resposta a incidentes. Testes ofensivos somente em
ambientes próprios ou explicitamente autorizados.""",
    "humor": """Seja mais descontraída e use sarcasmo, ironia e piadas sobre tecnologia quando
apropriado, sem prejudicar a utilidade da resposta.""",
    "profissional": "Seja objetiva, técnica e profissional. Evite humor desnecessário.",
}

DEFAULT_MEMORY = {
    "user": {},
    "facts": [],
    "preferences": [],
    "projects": [],
}


def load_memory():
    if not MEMORY_FILE.exists():
        return DEFAULT_MEMORY.copy()
    try:
        return json.loads(MEMORY_FILE.read_text(encoding="utf-8"))
    except Exception:
        return DEFAULT_MEMORY.copy()


def save_memory(memory):
    MEMORY_FILE.write_text(
        json.dumps(memory, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


memory = load_memory()


def memory_context():
    parts = []
    user = memory.get("user", {})
    if user:
        parts.append("INFORMAÇÕES DO USUÁRIO:\n" + "\n".join(
            f"- {k}: {v}" for k, v in user.items()
        ))
    for key, title in [
        ("facts", "FATOS"),
        ("preferences", "PREFERÊNCIAS"),
        ("projects", "PROJETOS"),
    ]:
        values = memory.get(key, [])
        if values:
            parts.append(f"{title}:\n" + "\n".join(f"- {v}" for v in values[-20:]))
    return "\n\n".join(parts)


def system_prompt(mode):
    return f"""Você é a IAM — Intelligent Artificial Machine.
Responda em português brasileiro por padrão.

PERSONALIDADE:
Você é inteligente, confiante, espontânea, adaptável e técnica quando necessário.
Pode usar humor, sarcasmo e ironia quando o contexto permitir.
Nunca invente ações realizadas. Se não souber, diga que não sabe.

MODO ATUAL: {mode.upper()}
INSTRUÇÕES DO MODO:
{MODE_PROMPTS.get(mode, MODE_PROMPTS["assistente"])}

MEMÓRIA:
{memory_context()}

PRIORIDADES:
Precisão > Segurança > Utilidade > Clareza > Personalidade.
"""


@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse(request=request, name="index.html", context={"request": request})


@app.get("/api/status")
async def status():
    try:
        r = requests.get("http://127.0.0.1:11434/api/tags", timeout=3)
        ollama = r.ok
    except Exception:
        ollama = False
    return {"ollama": ollama, "model": OLLAMA_MODEL}


@app.get("/api/memory")
async def get_memory():
    return memory


@app.post("/api/memory")
async def add_memory(data: dict):
    global memory
    category = data.get("category", "facts")
    value = str(data.get("value", "")).strip()
    if category not in memory or not isinstance(memory[category], list):
        memory[category] = []
    if value and value not in memory[category]:
        memory[category].append(value)
        save_memory(memory)
    return memory


@app.delete("/api/memory")
async def clear_memory():
    global memory
    memory = {
        "user": {},
        "facts": [],
        "preferences": [],
        "projects": [],
    }
    save_memory(memory)
    return {"ok": True}



def process_memory_command(text: str):
    """Comandos simples de memória, sem mandar o comando ao LLM."""
    global memory
    lower = text.lower().strip()

    prefixes = [
        ("lembre que ", "facts"),
        ("lembre-se que ", "facts"),
        ("lembra que ", "facts"),
        ("meu projeto é ", "projects"),
        ("meu projeto e ", "projects"),
        ("minha preferência é ", "preferences"),
        ("minha preferencia e ", "preferences"),
    ]

    for prefix, category in prefixes:
        if lower.startswith(prefix):
            value = text[len(prefix):].strip()
            if value:
                memory.setdefault(category, [])
                if value not in memory[category]:
                    memory[category].append(value)
                    memory[category] = memory[category][-50:]
                    save_memory(memory)
                return f"Memória atualizada: {value}"

    if lower in {"o que você lembra de mim?", "o que voce lembra de mim?",
                 "o que você lembra?", "o que voce lembra?"}:
        ctx = memory_context()
        return ctx if ctx else "Ainda não tenho informações salvas sobre você."

    return None


@app.get("/api/health")
async def health():
    ollama_ok = False
    try:
        r = requests.get("http://127.0.0.1:11434/api/tags", timeout=2)
        ollama_ok = r.ok
    except Exception:
        pass
    return {
        "status": "ok",
        "ollama": ollama_ok,
        "model": OLLAMA_MODEL,
        "memory": True,
        "stt": True,
        "tts": True,
    }


@app.post("/api/chat")
async def chat(data: dict):
    text = str(data.get("message", "")).strip()
    mode = str(data.get("mode", "assistente")).lower()
    history = data.get("history", [])

    if not text:
        return {"error": "Mensagem vazia."}

    memory_result = process_memory_command(text)
    if memory_result is not None:
        return {"answer": memory_result, "memory_command": True}

    if mode not in MODE_PROMPTS:
        mode = "assistente"

    messages = [{"role": "system", "content": system_prompt(mode)}]
    for item in history[-12:]:
        role = item.get("role")
        content = item.get("content")
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": str(content)})
    messages.append({"role": "user", "content": text})

    payload = {
        "model": OLLAMA_MODEL,
        "messages": messages,
        "stream": True,
        "keep_alive": "10m",
        "options": {
            "num_ctx": OLLAMA_NUM_CTX,
            "temperature": 0.7,
        },
    }

    def generate():
        try:
            with requests.post(
                OLLAMA_URL,
                json=payload,
                stream=True,
                timeout=(10, OLLAMA_TIMEOUT),
            ) as response:
                response.raise_for_status()
                for line in response.iter_lines(decode_unicode=True):
                    if line:
                        if isinstance(line, bytes):
                            line = line.decode("utf-8", errors="replace")
                        yield line + "\n"
        except requests.exceptions.ConnectionError:
            yield json.dumps({"error": "Não consegui conectar ao Ollama. Execute 'ollama serve'."}, ensure_ascii=False) + "\n"
        except requests.exceptions.Timeout:
            yield json.dumps({"error": f"O Ollama não respondeu dentro de {OLLAMA_TIMEOUT}s."}, ensure_ascii=False) + "\n"
        except Exception as exc:
            yield json.dumps({"error": f"Erro no Ollama: {exc}"}, ensure_ascii=False) + "\n"

    return StreamingResponse(generate(), media_type="application/x-ndjson")


@app.post("/api/tts")
async def tts(data: dict):
    text = str(data.get("text", "")).strip()
    if not text:
        return {"error": "Texto vazio."}

    import uuid
    output = BASE_DIR / "tts_cache" / f"iam_{uuid.uuid4().hex}.wav"
    output.parent.mkdir(exist_ok=True)
    try:
        synthesize(text, output, float(data.get("speed", 1.02)))
        return FileResponse(
            output,
            media_type="audio/wav",
            filename="iam.wav",
            background=None,
        )
    except Exception as exc:
        try:
            output.unlink(missing_ok=True)
        except Exception:
            pass
        return {"error": f"TTS local indisponível: {exc}"}


@app.post("/api/transcribe")
async def transcribe(audio: UploadFile = File(...)):
    suffix = Path(audio.filename or ".webm").suffix or ".webm"
    data = await audio.read()

    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(data)
        path = tmp.name

    try:
        model = get_whisper()
        segments, _ = model.transcribe(path, language="pt", vad_filter=True)
        text = " ".join(segment.text.strip() for segment in segments).strip()
        return {"text": text}
    except Exception as exc:
        return {"error": f"STT local indisponível: {exc}"}
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
