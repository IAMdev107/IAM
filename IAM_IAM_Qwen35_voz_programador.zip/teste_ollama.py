import json
import requests

url = "http://127.0.0.1:11434/api/chat"
payload = {
    "model": "qwen3.5:latest",
    "messages": [{"role": "user", "content": "Responda apenas: IAM online."}],
    "stream": True,
    "keep_alive": "10m",
}

print("Testando Ollama...")
with requests.post(url, json=payload, stream=True, timeout=(10, 300)) as r:
    r.raise_for_status()
    for line in r.iter_lines(decode_unicode=True):
        if line:
            if isinstance(line, bytes):
                line = line.decode("utf-8", errors="replace")
            obj = json.loads(line)
            content = obj.get("message", {}).get("content", "")
            if content:
                print(content, end="", flush=True)
print("\nOK")
