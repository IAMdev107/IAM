# IAM — Intelligent Artificial Machine

Uma IAM local integrada ao Ollama, com interface web, memória, modos especializados,
microfone pelo navegador, STT local e voz.

## ⚡ Instalação automática

Linux / Ubuntu / GitHub Codespaces:

```bash
chmod +x install.sh start.sh stop.sh
./install.sh
```

O instalador:

1. verifica Python;
2. instala dependências básicas quando `apt`/`sudo` estão disponíveis;
3. instala o Ollama se necessário;
4. cria `.venv`;
5. instala as bibliotecas Python;
6. inicia o Ollama quando necessário;
7. baixa `gpt-oss:20b` se ainda não existir;
8. cria o modelo personalizado `IAM` usando o `Modelfile`;
9. prepara a memória.

Depois:

```bash
./start.sh
```

Abra:

```text
http://localhost:8000
```

No GitHub Codespaces, encaminhe a porta **8000**.

## 🧠 Componentes

```text
🎤 Microfone
     ↓
Navegador
     ↓
FastAPI
     ↓
faster-whisper
     ↓
IAM
     ↓
Ollama / IAM
     ↓
Resposta
     ↓
SpeechSynthesis do navegador
     ↓
🔊 Alto-falante
```

O microfone **não usa PyAudio**, evitando os problemas de ALSA/JACK comuns em
containers e Codespaces.

## 🎛️ Modos

- 🟢 Assistente
- 🔵 Programador
- 🟣 Cibersegurança
- 🟡 Humor
- 🔴 Profissional

## 💾 Memória

A memória fica em:

```text
memory.json
```

A IAM também reconhece comandos simples:

```text
Lembre que meu projeto usa Python.
Lembre que meu projeto se chama IAM.
O que você lembra de mim?
```

A interface possui botão para apagar a memória.

## 🎤 Voz

O botão **Falar** usa o microfone do navegador e envia o áudio ao STT local.

Na primeira utilização do `faster-whisper`, o modelo STT configurado pode ser baixado.

Padrão:

```text
WHISPER_MODEL=small
WHISPER_DEVICE=cpu
WHISPER_COMPUTE=int8
```

Computador mais fraco:

```bash
WHISPER_MODEL=tiny ./start.sh
```

Melhor qualidade, mais pesado:

```bash
WHISPER_MODEL=medium ./start.sh
```

## 🔧 Comandos

Iniciar:

```bash
./start.sh
```

Parar:

```bash
./stop.sh
```

Reinstalar/atualizar:

```bash
./install.sh
```

Ver logs do Ollama:

```bash
cat ollama.log
```

## 🤖 Trocar modelo

Por padrão:

```text
gpt-oss:20b
```

Para outro modelo disponível no Ollama:

```bash
OLLAMA_MODEL="seu-modelo" ./install.sh
```

O `Modelfile` precisa ter um `FROM` compatível com o modelo escolhido.

## 🔐 Cibersegurança

A IAM é orientada a defesa, auditoria, hardening, análise de logs, vulnerabilidades,
monitoramento e testes autorizados. Não presuma autorização para atacar sistemas
de terceiros.

## 📁 Estrutura

```text
IAM/
├── app.py
├── Modelfile
├── install.sh
├── start.sh
├── stop.sh
├── fix.sh
├── requirements.txt
├── memory.json
├── README.md
├── templates/
│   └── index.html
└── static/
    ├── app.js
    └── style.css
```

## 🩹 Corrigir instalação existente

Se você já instalou uma versão anterior e apareceu o erro `cannot use 'tuple' as a dict key`, execute:

```bash
./fix.sh
```

A causa é a assinatura nova do `TemplateResponse` do Starlette. A IAM agora usa a chamada compatível com as versões atuais.


## ⚡ Resposta em streaming
A versão atual usa streaming da API do Ollama. Assim, a interface não precisa esperar a resposta inteira para mostrar o primeiro token. O modelo também fica mantido na memória por 10 minutos (`keep_alive`).

Se o computador tiver pouca RAM, reduza o contexto:
```bash
OLLAMA_NUM_CTX=2048 ./start.sh
```

Para testar o modelo diretamente:
```bash
ollama run IAM "Responda apenas: IAM online."
```

Para diagnosticar:
```bash
./diagnostico.sh
```
