#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
source .venv/bin/activate
VOICE="${IAM_TTS_VOICE:-pt_BR-faber-medium}"
echo "[IAM] Instalando/atualizando Piper TTS..."
python -m pip install -U 'piper-tts>=1.3,<2'
echo "[IAM] Baixando voz: $VOICE"
python -m piper.download_voices "$VOICE"
echo "[IAM] Voz instalada: $VOICE"
