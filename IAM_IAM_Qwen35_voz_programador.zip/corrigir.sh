#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo "[IAM] Corrigindo TemplateResponse..."

python3 - <<'PY'
from pathlib import Path
import re

p = Path("app.py")
s = p.read_text(encoding="utf-8")

s = re.sub(
    r'return templates\.TemplateResponse\([^\n]*\)',
    'return templates.TemplateResponse(request=request, name="index.html", context={"request": request})',
    s,
)

p.write_text(s, encoding="utf-8")
print("[IAM] app.py corrigido.")
PY

echo
echo "[IAM] Verificando a linha do TemplateResponse:"
grep -n "TemplateResponse" app.py || true

echo
echo "[IAM] Parando instâncias antigas do Uvicorn..."
pkill -f "uvicorn app:app" 2>/dev/null || true

echo "[IAM] Pronto."
echo "Agora execute:"
echo "  ./start.sh"
