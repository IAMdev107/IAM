#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"

if [ ! -d ".venv" ]; then
    echo "[IAM] Ambiente não instalado. Execute ./install.sh"
    exit 1
fi

source .venv/bin/activate

if ! curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    echo "[IAM] Iniciando Ollama..."
    nohup ollama serve > ollama.log 2>&1 &
    echo $! > ollama.pid
    for _ in $(seq 1 20); do
        curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1 && break
        sleep 1
    done
fi

if ! curl -fsS http://127.0.0.1:11434/api/tags >/dev/null 2>&1; then
    echo "[IAM] Ollama não respondeu. Veja ollama.log"
    exit 1
fi

echo
echo "=============================================="
echo " IAM — Intelligent Artificial Machine"
echo "=============================================="
echo " Ollama: OK"
echo " Web:    http://localhost:8000"
echo " Voz:    microfone pelo navegador"
echo "=============================================="
echo

echo "[IAM] Timeout Ollama: ${OLLAMA_TIMEOUT:-900}s | Contexto: ${OLLAMA_NUM_CTX:-4096}"
exec python -m uvicorn app:app --host 0.0.0.0 --port "${PORT:-8000}"
