# Correção do erro `can't concat str to bytes`

O erro vinha do streaming da resposta do Ollama. `requests.iter_lines()` pode
retornar `bytes`; o código antigo tentava concatenar `bytes` com `str`.

A correção converte explicitamente bytes para UTF-8 antes de enviar a linha.

## Instalação atual

```bash
cd /home/iam/IAM
chmod +x corrigir_ollama.sh
./corrigir_ollama.sh
./start.sh
```

## Teste direto

```bash
python teste_ollama.py
```

O modelo é `qwen3.5:latest`.
