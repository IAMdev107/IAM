const chat = document.getElementById("chat");
const form = document.getElementById("composer");
const message = document.getElementById("message");
const mode = document.getElementById("mode");
const modeLabel = document.getElementById("modeLabel");
const voiceBtn = document.getElementById("voiceBtn");
const stopVoiceBtn = document.getElementById("stopVoiceBtn");
const clearMemoryBtn = document.getElementById("clearMemoryBtn");
const statusText = document.getElementById("statusText");
const statusDot = document.getElementById("statusDot");

let history = [];
let mediaRecorder = null;
let chunks = [];
let currentAudio = null;
let speaking = false;

const labels = {
  assistente: "Modo Assistente",
  programador: "Modo Programador",
  ciberseguranca: "Modo Cibersegurança",
  humor: "Modo Humor",
  profissional: "Modo Profissional"
};

function addMessage(role, text) {
  const box = document.createElement("div");
  box.className = `msg ${role}`;
  const meta = document.createElement("div");
  meta.className = "meta";
  meta.textContent = role === "user" ? "Você" : "IAM";
  box.appendChild(meta);
  box.appendChild(document.createTextNode(text));
  chat.appendChild(box);
  chat.scrollTop = chat.scrollHeight;
}

function stopSpeaking() {
  if (currentAudio) {
    currentAudio.pause();
    currentAudio.currentTime = 0;
    currentAudio.src = "";
    currentAudio = null;
  }
  speaking = false;
}

async function speak(text) {
  stopSpeaking();
  const cleaned = text
    .replace(/```[\s\S]*?```/g, "")
    .replace(/`[^`]*`/g, "")
    .trim();
  if (!cleaned) return;

  try {
    const r = await fetch("/api/tts", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({text: cleaned, speed: 1.02})
    });
    const type = r.headers.get("content-type") || "";
    if (!r.ok || !type.includes("audio/wav")) {
      const data = await r.json().catch(() => ({}));
      throw new Error(data.error || `TTS HTTP ${r.status}`);
    }
    const blob = await r.blob();
    currentAudio = new Audio(URL.createObjectURL(blob));
    currentAudio.onplay = () => { speaking = true; };
    currentAudio.onended = () => { speaking = false; };
    currentAudio.onerror = () => { speaking = false; };
    await currentAudio.play();
  } catch (err) {
    // Fallback: voz nativa do navegador.
    if ("speechSynthesis" in window) {
      const u = new SpeechSynthesisUtterance(cleaned);
      u.lang = "pt-BR";
      u.rate = 1.0;
      u.pitch = 0.95;
      speechSynthesis.cancel();
      speechSynthesis.speak(u);
    }
    console.warn("Piper TTS falhou; usando voz do navegador:", err);
  }
}

mode.addEventListener("change", () => {
  modeLabel.textContent = labels[mode.value];
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const text = message.value.trim();
  if (!text) return;

  stopSpeaking();
  message.value = "";
  addMessage("user", text);
  history.push({role:"user", content:text});

  const thinking = document.createElement("div");
  thinking.className = "msg assistant";
  const meta = document.createElement("div");
  meta.className = "meta";
  meta.textContent = "IAM";
  thinking.appendChild(meta);
  const body = document.createElement("div");
  body.textContent = "🧠 Processando...";
  thinking.appendChild(body);
  chat.appendChild(thinking);
  chat.scrollTop = chat.scrollHeight;

  try {
    const r = await fetch("/api/chat", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({message:text, mode:mode.value, history:history})
    });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    if (!r.body) throw new Error("O navegador não suporta streaming.");

    const reader = r.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let answer = "";
    let gotToken = false;

    while (true) {
      const {value, done} = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, {stream:true});
      const lines = buffer.split("\n");
      buffer = lines.pop();

      for (const line of lines) {
        if (!line.trim()) continue;
        let data;
        try { data = JSON.parse(line); } catch { continue; }
        if (data.error) throw new Error(data.error);
        const token = data.message?.content || "";
        if (token) {
          if (!gotToken) { body.textContent = ""; gotToken = true; }
          answer += token;
          body.textContent = answer;
          chat.scrollTop = chat.scrollHeight;
        }
      }
    }

    if (!answer) throw new Error("O Ollama encerrou a resposta sem gerar texto.");
    history.push({role:"assistant", content:answer});
    await speak(answer);
  } catch (err) {
    body.textContent = "⚠️ " + (err?.message || err);
  }
});

voiceBtn.addEventListener("click", async () => {
  if (!navigator.mediaDevices?.getUserMedia) {
    alert("Seu navegador não permite acesso ao microfone.");
    return;
  }

  if (mediaRecorder && mediaRecorder.state === "recording") {
    mediaRecorder.stop();
    return;
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({
      audio: {echoCancellation:true, noiseSuppression:true, autoGainControl:true}
    });
    mediaRecorder = new MediaRecorder(stream, {mimeType:"audio/webm"});
    chunks = [];

    mediaRecorder.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
    mediaRecorder.onstop = async () => {
      stream.getTracks().forEach(t => t.stop());
      voiceBtn.textContent = "🎤 Falar";
      const blob = new Blob(chunks, {type:"audio/webm"});
      const fd = new FormData();
      fd.append("audio", blob, "iam.webm");
      voiceBtn.textContent = "🧠 Entendendo...";
      try {
        const r = await fetch("/api/transcribe", {method:"POST", body:fd});
        const data = await r.json();
        if (data.text) {
          message.value = data.text;
          form.requestSubmit();
        } else if (data.error) {
          startBrowserSpeech();
        }
      } catch { startBrowserSpeech(); }
      finally { voiceBtn.textContent = "🎤 Falar"; }
    };

    stopSpeaking();
    mediaRecorder.start();
    voiceBtn.textContent = "⏹️ Parar gravação";
  } catch (err) {
    alert("Não foi possível acessar o microfone: " + err);
  }
});

function startBrowserSpeech() {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    alert("STT local não respondeu e o navegador não possui reconhecimento de voz.");
    return;
  }
  const rec = new Recognition();
  rec.lang = "pt-BR";
  rec.interimResults = false;
  rec.maxAlternatives = 1;
  voiceBtn.textContent = "🧠 Ouvindo...";
  rec.onresult = e => { message.value = e.results[0][0].transcript; form.requestSubmit(); };
  rec.onerror = () => alert("Não consegui reconhecer a fala.");
  rec.onend = () => voiceBtn.textContent = "🎤 Falar";
  rec.start();
}

stopVoiceBtn.addEventListener("click", () => {
  stopSpeaking();
  if ("speechSynthesis" in window) speechSynthesis.cancel();
});

clearMemoryBtn.addEventListener("click", async () => {
  if (!confirm("Apagar toda a memória da IAM?")) return;
  await fetch("/api/memory", {method:"DELETE"});
  alert("Memória apagada.");
});

async function checkStatus() {
  try {
    const r = await fetch("/api/status");
    const data = await r.json();
    if (data.ollama) {
      statusDot.style.background = "#32d583";
      statusText.textContent = `Ollama online — ${data.model}`;
    } else {
      statusDot.style.background = "#ef4444";
      statusText.textContent = "Ollama offline";
    }
  } catch {
    statusDot.style.background = "#ef4444";
    statusText.textContent = "Backend offline";
  }
}

addMessage("assistant", "Sistema IAM online. Fale comigo ou digite uma mensagem.");
checkStatus();
setInterval(checkStatus, 10000);
