#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo '=== IAM DIAGNÓSTICO ==='
echo
echo '[1] Ollama:'
curl -fsS http://127.0.0.1:11434/api/tags || true
echo
echo
echo '[2] Modelos instalados:'
ollama list || true
echo
echo '[3] Teste rápido do modelo IAM:'
timeout 120 ollama run IAM 'Responda apenas: IAM online.' || true
echo
echo '[4] Memória RAM:'
free -h || true
echo
echo '[5] Porta 8000:'
ss -ltnp 2>/dev/null | grep ':8000' || true
