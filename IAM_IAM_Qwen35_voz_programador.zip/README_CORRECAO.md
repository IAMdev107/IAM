# Correção do erro TemplateResponse

O traceback:

```text
TypeError: cannot use 'tuple' as a dict key (unhashable type: 'dict')
```

indica que o processo que está rodando ainda está usando a chamada antiga:

```python
templates.TemplateResponse("index.html", {"request": request})
```

A versão corrigida usa:

```python
templates.TemplateResponse(
    request=request,
    name="index.html",
    context={"request": request},
)
```

## Se já tem a IAM instalada

```bash
cd /home/iam/IAM
chmod +x corrigir.sh
./corrigir.sh
./start.sh
```

## Verificação

Execute:

```bash
grep -n "TemplateResponse" app.py
```

Deve aparecer:

```text
return templates.TemplateResponse(request=request, name="index.html", context={"request": request})
```

## Modelo

Esta versão usa:

```text
qwen3.5:latest
```

Por padrão.

Teste diretamente:

```bash
ollama run qwen3.5:latest
```

Ou, se criou o modelo personalizado:

```bash
ollama create IAM -f Modelfile
OLLAMA_MODEL=IAM ./start.sh
```
